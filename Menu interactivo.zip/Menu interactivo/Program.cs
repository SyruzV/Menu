﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Elige una opcion\n" +
            "\n1.- Suma" +
            "\n2.- Resta" +
            "\n3.- Multiplicacion" +
            "\n4.- Division" +
            "n5.- Salir\n");

            string s1 = null;

            s1 = Console.ReadKey().ToString();

            switch(s1){
                case "1":

                    Console.WriteLine("Opciones Suma");
                    Console.WriteLine("Escribe tu primer numero");
                    double num1 = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe tu segundo numero");
                    double num2 = Convert.ToDouble(Console.ReadLine());

                    double resultado;
                    resultado = num1 + num2;

                    Console.WriteLine("Tu resultado es" + resultado);
                    Console.ReadLine();

                    break;
                case "2":
                    Console.WriteLine("Opciones Resta");
                    Console.WriteLine("Escribe tu primer numero");
                    double num3 = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe tu segundo numero");
                    double num4 = Convert.ToDouble(Console.ReadLine());

                    double resultado2;
                    resultado2 = num3 - num4;

                    Console.WriteLine("Tu resultado es" + resultado2);
                    Console.ReadLine();

                    break;
                case "3":
                    Console.WriteLine("Opciones Multiplicacion");
                    Console.WriteLine("Escribe tu primer numero");
                    double num5 = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe tu segundo numero");
                    double num6 = Convert.ToDouble(Console.ReadLine());

                    double resultado3;
                    resultado3 = num5 * num6;

                    Console.WriteLine("Tu resultado es" + resultado3);
                    Console.ReadLine();

                    break;
                case "4":
                    Console.WriteLine("Opciones Division");
                    Console.WriteLine("Escribe tu primer numero");
                    double num7 = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine("Escribe tu segundo numero");
                    double num8 = Convert.ToDouble(Console.ReadLine());

                    double resultado4;
                    resultado4 = num7 / num8;

                    Console.WriteLine("Tu resultado es" + resultado4);
                    Console.ReadLine();

                    break;
                case "5":
                    Console.WriteLine("Opciones Salir");
                    break;
                default:
                    Console.WriteLine("No se ha seleccionado una opcion");
                    break;
            }
        }
    }
}